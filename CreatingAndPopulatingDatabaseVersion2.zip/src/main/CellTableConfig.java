package main;

import java.awt.List;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Locale;

import persistence.PersistenceUtil;
import entity.CellTable;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

public class CellTableConfig {

	public CellTableConfig() {
		try {

			String inputFile = "data.xls";
			WorkbookSettings workbookSettings = new WorkbookSettings();
			workbookSettings.setLocale(new Locale("en", "EN"));
			Workbook w = Workbook.getWorkbook(new File(inputFile),
					workbookSettings);

			// Gets the sheets from workbook

			Sheet currentSheet = w.getSheet(0);
			Cell[] row = null;

			// Gets the cells from sheet
			for (int i = 1; i < currentSheet.getRows(); i++) {
				row = currentSheet.getRow(i);

				if (row.length > 0) {

					createCellTable(Integer.parseInt(row[6].getContents()), row[11].getContents(), row[12].getContents(), row[13].getContents());

				}

			}

		} catch (UnsupportedEncodingException e) {
			System.err.println(e.toString());
		} catch (IOException e) {
			System.err.println(e.toString());
		} catch (Exception e) {
			System.err.println(e.toString());
		}
	}

	public void createCellTable(int cellID, String hier3_ID, String hier32_ID, String hier321_ID) {
		CellTable cellTable = new CellTable(cellID, hier3_ID, hier32_ID, hier321_ID);
		PersistenceUtil.persist(cellTable);
		//System.out.println("Subscriber registered");
	}

}
