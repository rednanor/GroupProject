package main;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.text.ParseException;
import java.text.SimpleDateFormat;

//import java.util.Date;
import jxl.*;
import persistence.PersistenceUtil;
import entity.BaseData;

;

public class BaseDataConfig {

	//SimpleDateFormat format = new SimpleDateFormat("yy/dd/mm HH:mm");
	SimpleDateFormat format = new SimpleDateFormat("dd/m/yyyy HH:mm");
	
	public BaseDataConfig() {
		try {

			String inputFile = "data.xls";
			WorkbookSettings workbookSettings = new WorkbookSettings();
			workbookSettings.setLocale(new Locale("en", "EN"));
			Workbook w = Workbook.getWorkbook(new File(inputFile),
					workbookSettings);

			// Gets the sheets from workbook
			for (int sheetNum = 0; sheetNum < 1; sheetNum++) {

				Sheet currentSheet = w.getSheet(sheetNum);
				Cell[] row = null;

				// Gets the cells from sheet
				for (int i = 1; i < currentSheet.getRows(); i++) {
					row = currentSheet.getRow(i);

					if (row.length > 0) {
						// for (int j = 1; j < row.length; j++) {
//						System.out.println(row[1].getContents() + " "
//								+ row[2].getContents() + " "
//								+ row[3].getContents() + " "
//								+ row[0].getContents());
						
						
						
						String dateSample = row[0].getContents();

					    String oldFormat = "M/dd/yy HH:mm";
					    String newFormat = "yyyy/MM/dd HH:mm";

					    SimpleDateFormat sdf1 = new SimpleDateFormat(oldFormat);
					    SimpleDateFormat sdf2 = new SimpleDateFormat(newFormat);
					    String nda = "";

					    try {
					      //  System.out.println(sdf2.format(sdf1.parse(dateSample)));
					      nda = sdf2.format(sdf1.parse(dateSample));
					    } catch (ParseException e) {
					        // TODO Auto-generated catch block
					        e.printStackTrace();
					    }
						
						
						java.util.Date date = sdf2.parse(nda);
						//System.out.println(row[0].getContents());
						java.sql.Date sql = new java.sql.Date(date.getTime());  
						//System.out.println(date);
						
						//int eventCauseID, int mccmncID, int cellID, int duration, int imsi, String failureClassID, String TAC, String neVersion, Date baseDate
						String eventCause = (row[1].getContents()) + row[8].getContents();
						createData(eventCause, i, (Integer.parseInt(row[6].getContents())),
								(Integer.parseInt(row[7].getContents())), row[10].getContents(),
								row[2].getContents(), row[3].getContents(), row[9].getContents(), sql);
						 
					}

				}

			}

		} catch (UnsupportedEncodingException e) {
			System.err.println(e.toString());
		} catch (IOException e) {
			System.err.println(e.toString());
		} catch (Exception e) {
			System.err.println(e.toString());
		}
	}

	//
	// private void createData(int parseInt, String parseInt2, String contents,
	// Date parse) {
	// BaseData baseData = new BaseData(parseInt, parseInt2, contents, parse);
	// PersistenceUtil.persist(baseData);
	// System.out.println("Subscriber registered");
	// // TODO Auto-generated method stub
	//
	// }

//	public void viewBaseData() {
//		List<BaseData> baseDatas = PersistenceUtil.findAllBaseData();
//		for (BaseData bd : baseDatas) {
//			// System.out.println("Subscriber "+s.getUsername()+ " exists.");
//		}
//	}

	public void createData(String eventCauseID, int mccmncID, int cellID, int duration, String imsi, String failureClassID, String TAC, String neVersion, Date baseDate) {
		BaseData baseData = new BaseData(eventCauseID, mccmncID, cellID, duration, imsi, failureClassID, TAC, neVersion, baseDate);
		PersistenceUtil.persist(baseData);
		//PersistenceUtil.findIMSIEvent();
		//System.out.println("Subscriber registered");
		// viewSubscriber();
	}

}
