package main;

public class Driver {

	public static void main(String[] args) {
		CountryConfig cConfig = new CountryConfig();
		AccessCapabilityConfig acConfig = new AccessCapabilityConfig();
		UE_AccessCapabilityConfig ue_ACC = new UE_AccessCapabilityConfig();
		CellTableConfig ctConfig = new CellTableConfig();
		EventCauseConfig ecConfig = new EventCauseConfig();
		FailureConfig fConfig = new FailureConfig();
		ManufacturerConfig mConfig = new ManufacturerConfig();
		MCCMNCConfig mccmncConfig = new MCCMNCConfig();
		UEModelConfig ueModelConfig = new UEModelConfig();
		UserEquipmentConfig ueConfig = new UserEquipmentConfig();
		BaseDataConfig bdconfig = new BaseDataConfig();
		
	}
}
