package entity;

public class UE {

}
